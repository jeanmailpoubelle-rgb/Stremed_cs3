/* Runs only in the extension service worker. Pairing credentials never enter page scripts. */
'use strict';
const FinderDevice = (() => {
  const domain = 'cloudstream-device/v1', encoder = new TextEncoder(), decoder = new TextDecoder();
  const storageKey = 'paired-tv-v1', candidateKey = 'pending-tv-v1';
  let changes = Promise.resolve(), pairingWatch = null;
  function serial(task) {
    const result = changes.then(task);
    changes = result.catch(() => {});
    return result;
  }
  const b64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  function unb64(text, size) {
    if (typeof text !== 'string' || text.length > 131072 || !/^[A-Za-z0-9_-]*$/.test(text)) throw Error('Invalid receiver response.');
    const bytes = Uint8Array.from(atob(text.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
    if (b64(bytes) !== text || size !== undefined && bytes.length !== size) throw Error('Invalid receiver response.');
    return bytes;
  }
  const random = size => crypto.getRandomValues(new Uint8Array(size));
  const concat = (...parts) => { const result = new Uint8Array(parts.reduce((n, p) => n + p.length, 0)); let offset = 0; for (const p of parts) { result.set(p, offset); offset += p.length; } return result; };
  function address(value) {
    // IP literals only: no DNS rebinding or arbitrary LAN services. First version uses IPv4.
    const match = /^(?:http:\/\/)?(\d{1,3}(?:\.\d{1,3}){3})(?::49835)?\/?$/.exec(String(value).trim());
    if (!match) throw Error('Enter the private IPv4 address shown by Cloudstream on the TV.');
    const parts = match[1].split('.').map(Number);
    if (parts.some((p, i) => p > 255 || String(p) !== match[1].split('.')[i]) || !(parts[0] === 10 || parts[0] === 192 && parts[1] === 168 || parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31)) throw Error('Use a private Wi-Fi IPv4 address.');
    return `http://${parts.join('.')}:49835`;
  }
  async function derive(pair, remote, clientNonce, serverNonce, clientKey, serverKey, id) {
    unb64(id, 16);
    const publicKey = await crypto.subtle.importKey('raw', remote, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
    const shared = await crypto.subtle.deriveBits({ name: 'ECDH', public: publicKey }, pair.privateKey, 256);
    const salt = await crypto.subtle.digest('SHA-256', concat(clientNonce, serverNonce));
    const key = await crypto.subtle.importKey('raw', shared, 'HKDF', false, ['deriveBits']);
    return new Uint8Array(await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt,
      info: concat(encoder.encode(`${domain}/pair/${id}`), clientKey, serverKey) }, key, 256));
  }
  async function code(key) {
    const imported = await crypto.subtle.importKey('raw', key, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    const hash = await crypto.subtle.sign('HMAC', imported, encoder.encode(`${domain}/verify`));
    return String(new DataView(hash).getUint32(0) % 1000000).padStart(6, '0');
  }
  async function crypt(mode, key, purpose, id, iv, data) {
    const imported = await crypto.subtle.importKey('raw', key, 'AES-GCM', false, [mode]);
    return new Uint8Array(await crypto.subtle[mode]({ name: 'AES-GCM', iv, additionalData: encoder.encode(`${domain}/${purpose}/${id}`), tagLength: 128 }, imported, data));
  }
  async function request(base, path, data) {
    const response = await fetch(address(base) + '/v1/' + path, { method: data ? 'POST' : 'GET',
      headers: data ? { 'Content-Type': 'application/json' } : {}, body: data ? JSON.stringify(data) : undefined,
      credentials: 'omit', redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(8000) });
    const reader = response.body.getReader();
    const chunks = []; let size = 0;
    for (;;) {
      const { done, value } = await reader.read(); if (done) break;
      size += value.length;
      if (size > 100000) { await reader.cancel(); throw Error('Invalid receiver response.'); }
      chunks.push(value);
    }
    const text = decoder.decode(concat(...chunks));
    if (!response.ok) throw Error(response.status === 403 ? 'Open pairing on the TV, or pair again.' : 'The TV rejected this request.');
    return JSON.parse(text);
  }
  async function command(device, purpose, payload = {}) {
    const info = await request(device.address, 'info');
    if (info.protocol !== 1) throw Error('Update Browser Stream Bridge on the TV.');
    unb64(info.epoch, 16);
    if (!Number.isSafeInteger(info.time)) throw Error('Invalid receiver response.');
    const iv = random(12), key = unb64(device.key, 32);
    const body = await crypt('encrypt', key, purpose, device.id, iv, encoder.encode(JSON.stringify({ time: info.time, epoch: info.epoch, ...payload })));
    const response = await request(device.address, purpose, { id: device.id, iv: b64(iv), body: b64(body) });
    if (response.id !== device.id) throw Error('Invalid receiver response.');
    const clear = await crypt('decrypt', key, 'reply', device.id, unb64(response.iv, 12), unb64(response.body));
    const result = JSON.parse(decoder.decode(clear));
    if (result.request !== b64(iv)) throw Error('Invalid receiver response.');
    return result;
  }
  async function state() {
    const device = (await chrome.storage.local.get(storageKey))[storageKey];
    const candidate = (await chrome.storage.session.get(candidateKey))[candidateKey];
    if (candidate && Date.now() >= candidate.expires) await chrome.storage.session.remove(candidateKey);
    return { device: device ? { name: device.name, address: device.address } : null,
      pending: candidate && Date.now() < candidate.expires ? { code: candidate.code, address: candidate.address } : null };
  }
  async function pairStart(value) {
    await chrome.storage.session.remove(candidateKey);
    const base = address(value), pair = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
    const clientKey = new Uint8Array(await crypto.subtle.exportKey('raw', pair.publicKey)), clientNonce = random(32);
    const commit = await crypto.subtle.digest('SHA-256', concat(clientKey, clientNonce));
    const response = await request(base, 'pair', { name: 'Media Finder phone', commit: b64(commit) });
    const serverKey = unb64(response.key, 65), serverNonce = unb64(response.nonce, 32);
    const key = await derive(pair, serverKey, clientNonce, serverNonce, clientKey, serverKey, response.id);
    await request(base, 'pair-reveal', { id: response.id, key: b64(clientKey), nonce: b64(clientNonce) });
    const candidate = { address: base, id: response.id, key: b64(key), code: await code(key), expires: Date.now() + 120000 };
    await chrome.storage.session.set({ [candidateKey]: candidate });
    resumePairing();
    return state();
  }
  async function pairCheck() {
    const candidate = (await chrome.storage.session.get(candidateKey))[candidateKey];
    if (!candidate || candidate.expires <= Date.now()) return state();
    const answer = await command(candidate, 'status');
    if (answer.paired !== true || candidate.expires <= Date.now()) return state();
    await chrome.storage.local.set({ [storageKey]: { id: candidate.id, address: candidate.address, key: candidate.key, name: 'Cloudstream TV' } });
    await chrome.storage.session.remove(candidateKey);
    return state();
  }
  function resumePairing() {
    if (pairingWatch) return;
    // Only the two-minute pending handshake keeps this worker active. No paired/idle polling.
    pairingWatch = (async () => {
      try {
        while ((await state()).pending) {
          try { await serial(pairCheck); } catch { /* A short network interruption can recover within the pairing window. */ }
          if (!(await state()).pending) break;
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      } finally {
        pairingWatch = null;
        // A new attempt may have been stored just as the old watcher was exiting.
        if ((await state()).pending) resumePairing();
      }
    })();
    pairingWatch.catch(() => {});
  }
  function carrier(value) {
    if (typeof value !== 'string' || value.length > 65536) throw Error('Invalid playback data.');
    const url = new URL(value);
    if (url.origin !== 'https://browser-stream.cloudstream.invalid' || url.pathname !== '/play' || url.hash || url.username || url.password) throw Error('Only Browser Stream Bridge media can be sent.');
    return value; // Android applies the full strict protocol validation.
  }
  async function send(value) {
    // Also recover an approved handshake if Android suspended the extension worker.
    await serial(pairCheck);
    const device = (await chrome.storage.local.get(storageKey))[storageKey];
    if (!device) throw Error('Pair the TV in the extension menu first.');
    const answer = await command(device, 'play', { carrier: carrier(value) });
    if (!answer.accepted) throw Error('Enable the TV companion receiver and check its Cloudstream player setting.');
    return { ok: true };
  }
  async function forget() { await chrome.storage.local.remove(storageKey); await chrome.storage.session.remove(candidateKey); return state(); }
  return { state, pairStart: value => serial(() => pairStart(value)), resumePairing, send,
    forget: () => serial(forget), address, derive, code, crypt, b64, unb64, carrier };
})();
