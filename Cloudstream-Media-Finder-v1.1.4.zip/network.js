/* Shared bounded network classification. No cookies, credentials or binary bodies. */
(() => {
  'use strict';
  const SAFE = new Set(['accept', 'accept-language', 'x-requested-with']);
  function url(value) {
    try {
      const u = new URL(value);
      return ['http:', 'https:'].includes(u.protocol) && !u.username && !u.password && u.href.length <= 16384 ? u.href : null;
    } catch { return null; }
  }
  function headers(rows) {
    const out = { requestHeaders: {}, suggestedReferer: '', suggestedOrigin: '' };
    for (const h of Array.isArray(rows) ? rows.slice(0, 100) : []) {
      const name = String(h.name || '').toLowerCase(), value = h.value;
      if (typeof value !== 'string' || value.length > 4096 || /[\u0000-\u001f\u007f]/.test(value)) continue;
      if (SAFE.has(name)) out.requestHeaders[name] = value;
      else if (name === 'referer' && url(value)) out.suggestedReferer = value;
      else if (name === 'origin' && (value === 'null' || url(value) && new URL(value).origin === value)) out.suggestedOrigin = value;
      else if (name === 'user-agent' && value.length <= 1024) out.browserAgent = value;
    }
    return out;
  }
  function mime(rows) {
    const value = (rows || []).find(h => h.name.toLowerCase() === 'content-type')?.value;
    return typeof value === 'string' ? value.slice(0, 160) : '';
  }
  function classify(value, type = '', contentType = '') {
    const u = url(value); if (!u) return null;
    const path = new URL(u).pathname;
    if (/\.(?:ts|m4s|m4a|aac|key|jpg|jpeg|png|webp|gif)(?:$)/i.test(path)) return null;
    if (/(?:^|\/)(?:init|segment|chunk|fragment)[-_.\d][^/]*\.(?:mp4|webm)$/i.test(path)) return null;
    if (/text\/vtt|(?:application|text)\/(?:x-subrip|ttml\+xml|(?:x-)?ass|(?:x-)?ssa)/i.test(contentType) ||
        /\.(?:vtt|srt|ass|ssa|ttml)$/i.test(path)) {
      return /(?:thumb|sprite|storyboard|chapter)/i.test(path) ? null : 'subtitle';
    }
    if (/mpegurl|dash\+xml|^(?:video|audio)\//i.test(contentType) || /\.(?:m3u8|mpd|mp4|webm|mkv|mov|m4v|ogv|mp3|ogg|wav|flac|opus)$/i.test(path)) return 'media';
    return type === 'media' && !/text\/html|image\//i.test(contentType) ? 'native' : null;
  }
  globalThis.FinderNetwork = { url, headers, mime, classify };
})();
