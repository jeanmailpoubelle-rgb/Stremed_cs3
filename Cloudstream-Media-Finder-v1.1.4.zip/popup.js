'use strict';
document.querySelector('#open').addEventListener('click', async () => {
  const status = document.querySelector('#status');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https?:\/\//.test(tab.url || '')) throw new Error('restricted');
    await chrome.tabs.sendMessage(tab.id, { type: 'open' }, { frameId: 0 });
    window.close();
  } catch {
    status.textContent = 'Open a normal website, allow this extension on that site, and reload the page. Browser settings and store pages cannot be scanned.';
  }
});
async function tvRequest(type, data = {}) {
  const result = await chrome.runtime.sendMessage({ type, ...data });
  if (result?.error) throw Error(result.error);
  return result;
}
function showTv(state) {
  document.querySelector('#tv-state').textContent = state?.device ? `Paired: ${state.device.name} · ${state.device.address}` : 'No TV paired.';
  document.querySelector('#forget').hidden = !state?.device;
  document.querySelector('#pair-code').textContent = state?.pending ? `Code: ${state.pending.code}\nCompare this code on both devices and approve it once on the TV. Pairing completes automatically.` : '';
  if (state?.pending) document.querySelector('#tv').open = true;
  if (state?.device) document.querySelector('#address').value = state.device.address;
}
async function action(button, task) {
  button.disabled = true;
  try { showTv(await task()); }
  catch (error) { document.querySelector('#pair-code').textContent = error.message; }
  finally { button.disabled = false; }
}
document.querySelector('#pair').onclick = event => action(event.currentTarget, () => tvRequest('tv-pair-start', { address: document.querySelector('#address').value }));
document.querySelector('#forget').onclick = event => action(event.currentTarget, () => tvRequest('tv-forget'));
chrome.storage.onChanged.addListener((changes, area) => {
  if ((area === 'local' && changes['paired-tv-v1']) || (area === 'session' && changes['pending-tv-v1']))
    tvRequest('tv-state').then(showTv).catch(() => {});
});
tvRequest('tv-state').then(showTv).catch(() => {});

// Let the browser verify and install signed packages. Never fetch/evaluate remote
// JavaScript or replace installed files ourselves. No extension polling/timer.
document.querySelector('#extension-version').textContent = `Installed version: ${chrome.runtime.getManifest().version}`;
const updateStatus = document.querySelector('#update-status');
const checkUpdate = document.querySelector('#check-update');
const applyUpdate = document.querySelector('#apply-update');
checkUpdate.onclick = () => {
  if (typeof chrome.runtime.requestUpdateCheck !== 'function') {
    updateStatus.textContent = 'This browser does not expose its extension updater. Use a manual CRX update.';
    return;
  }
  checkUpdate.disabled = true;
  updateStatus.textContent = 'Asking the browser to check for updates…';
  try {
    chrome.runtime.requestUpdateCheck((status, details) => {
      checkUpdate.disabled = false;
      if (chrome.runtime.lastError) {
        updateStatus.textContent = 'The browser could not check. Signed CRX updates may be unsupported for this installation.';
      } else if (status === 'update_available') {
        applyUpdate.hidden = false;
        updateStatus.textContent = `Version ${details?.version || ''} is available. Restart the extension to apply it; TV pairing is kept.`;
      } else if (status === 'throttled') {
        updateStatus.textContent = 'The browser has limited update checks. Try later, or use Update on its extensions page.';
      } else if (status === 'no_update') {
        updateStatus.textContent = 'The browser reports no update. This does not confirm that self-hosted updates are supported; check again after a newer release.';
      } else {
        updateStatus.textContent = 'The browser returned an unknown update result. Use its extensions page or a manual CRX update.';
      }
    });
  } catch {
    checkUpdate.disabled = false;
    updateStatus.textContent = 'Update checks are unavailable in this browser. Use a manual CRX update.';
  }
};
applyUpdate.onclick = () => chrome.runtime.reload();
