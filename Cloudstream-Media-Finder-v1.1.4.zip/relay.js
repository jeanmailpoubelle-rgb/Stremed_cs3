/* Isolated world: page messages cannot invoke arbitrary extension APIs. */
(() => {
  'use strict';
  const CHANNEL = 'cloudstream-media-finder/extension/1';
  let ready = false, pending = [], sendUntil = 0;
  const emit = event => window.postMessage({ channel: CHANNEL, type: 'network', event }, '*');
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id) return;
    if (message.type === 'network' && message.event) {
      if (ready) emit(message.event);
      else { pending.push(message.event); pending = pending.slice(-180); }
      reply({ ok: true });
    } else if (message.type === 'open' && window === window.top) {
      window.postMessage({ channel: CHANNEL, type: 'open' }, '*');
      reply({ ok: true });
    }
  });
  // A page cannot silently send media just by posting a message. Only a real
  // user click on the Finder's Send button opens a single-use, short-lived gate.
  window.addEventListener('click', event => {
    if (!event.isTrusted || window !== window.top) return;
    const path = event.composedPath();
    const button = path.find(n => n?.dataset?.finderDevice === 'send');
    const host = document.getElementById('cloudstream-media-finder');
    if (button && host && path.includes(host) && button.getRootNode() === host.shadowRoot) sendUntil = performance.now() + 1500;
  }, true);
  window.addEventListener('message', event => {
    if (event.source !== window || event.data?.channel !== CHANNEL) return;
    const message = event.data;
    if (message.type === 'device-state' && window === window.top) {
      chrome.runtime.sendMessage({ type: 'tv-state' }).then(state => {
        window.postMessage({ channel: CHANNEL, type: 'device-state-result', paired: !!state?.paired }, '*');
      }).catch(() => {});
    } else if (message.type === 'device-send' && window === window.top) {
      if (!sendUntil || performance.now() > sendUntil) return;
      sendUntil = 0;
      if (typeof message.request !== 'string' || message.request.length > 60 || typeof message.carrier !== 'string' || message.carrier.length > 65536) return;
      chrome.runtime.sendMessage({ type: 'tv-send', carrier: message.carrier }).then(result => {
        window.postMessage({ channel: CHANNEL, type: 'device-send-result', request: message.request,
          ok: !!result?.ok, error: result?.error || '' }, '*');
      }).catch(() => {
        window.postMessage({ channel: CHANNEL, type: 'device-send-result', request: message.request, ok: false, error: 'TV connection failed.' }, '*');
      });
    } else if (message.type === 'ready') {
      ready = true;
      chrome.runtime.sendMessage({ type: 'ready' }).then(result => {
        for (const row of result?.events || []) emit(row);
        for (const row of pending) emit(row);
        pending = [];
      }).catch(() => {});
    } else if (message.type === 'clear' && window === window.top) {
      chrome.runtime.sendMessage({ type: 'clear' }).catch(() => {});
    } else if (message.type === 'count' && window === window.top && Number.isInteger(message.count)) {
      chrome.runtime.sendMessage({ type: 'count', count: Math.min(150, Math.max(0, message.count)) }).catch(() => {});
    }
  });
  window.postMessage({ channel: CHANNEL, type: 'hello' }, '*');
})();
