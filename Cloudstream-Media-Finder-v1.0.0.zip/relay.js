/* Isolated world: page messages cannot invoke arbitrary extension APIs. */
(() => {
  'use strict';
  const CHANNEL = 'cloudstream-media-finder/extension/1';
  let ready = false, pending = [];
  const emit = event => window.postMessage({ channel: CHANNEL, type: 'network', event }, '*');
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id) return;
    if (message.type === 'network' && message.event) {
      if (ready) emit(message.event);
      else { pending.push(message.event); pending = pending.slice(-180); }
      reply({ ok: true });
    } else if (message.type === 'open' && window === window.top) {
      window.postMessage({ channel: CHANNEL, type: 'open' }, '*');
      reply({ ok: true });
    }
  });
  window.addEventListener('message', event => {
    if (event.source !== window || event.data?.channel !== CHANNEL) return;
    const message = event.data;
    if (message.type === 'ready') {
      ready = true;
      chrome.runtime.sendMessage({ type: 'ready' }).then(result => {
        for (const row of result?.events || []) emit(row);
        for (const row of pending) emit(row);
        pending = [];
      }).catch(() => {});
    } else if (message.type === 'clear' && window === window.top) {
      chrome.runtime.sendMessage({ type: 'clear' }).catch(() => {});
    } else if (message.type === 'count' && window === window.top && Number.isInteger(message.count)) {
      chrome.runtime.sendMessage({ type: 'count', count: Math.min(150, Math.max(0, message.count)) }).catch(() => {});
    }
  });
  window.postMessage({ channel: CHANNEL, type: 'hello' }, '*');
})();
