'use strict';
document.querySelector('#open').addEventListener('click', async () => {
  const status = document.querySelector('#status');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https?:\/\//.test(tab.url || '')) throw new Error('restricted');
    await chrome.tabs.sendMessage(tab.id, { type: 'open' }, { frameId: 0 });
    window.close();
  } catch {
    status.textContent = 'Open a normal website, allow this extension on that site, and reload the page. Browser settings and store pages cannot be scanned.';
  }
});
