/* MV3 receiver. Observations live in browser-session storage, never online. */
'use strict';
importScripts('network.js', 'device.js');
const N = FinderNetwork, pending = new Map(), queues = new Map();
const FILTER = { urls: ['http://*/*', 'https://*/*'] };
const MAX_EVENTS = 180, MAX_REQUESTS = 700, TTL = 30 * 60 * 1000;
const key = tab => `finder:${tab}`;
async function serial(tab, task) {
  const previous = queues.get(tab) || Promise.resolve();
  const next = previous.catch(() => {}).then(task);
  queues.set(tab, next);
  try { return await next; } finally { if (queues.get(tab) === next) queues.delete(tab); }
}
async function read(tab) {
  const rows = (await chrome.storage.session.get(key(tab)))[key(tab)] || [];
  return rows.filter(e => Date.now() - e.time < TTL);
}
function target(event) {
  return event.documentId ? { documentId: event.documentId } : { frameId: event.frameId };
}
async function send(tab, event) {
  try { await chrome.tabs.sendMessage(tab, { type: 'network', event }, target(event)); } catch { /* frame may not yet be ready */ }
}
async function save(tab, event) {
  await serial(tab, async () => {
    const rows = (await read(tab)).filter(e => !(e.url === event.url && e.frameId === event.frameId && e.documentId === event.documentId));
    rows.push(event);
    try { await chrome.storage.session.set({ [key(tab)]: rows.slice(-MAX_EVENTS) }); }
    catch { /* Storage quota must not prevent live detection. */ }
    // Send inside the queue: navigation cleanup cannot deliver stale data afterwards.
    await send(tab, event);
  });
}
function prunePending() {
  for (const [id, event] of pending) if (Date.now() - event.time > 60000) pending.delete(id);
  while (pending.size > MAX_REQUESTS) pending.delete(pending.keys().next().value);
}
function request(details) {
  if (details.tabId < 0 || ['main_frame', 'sub_frame', 'ping'].includes(details.type) || !N.url(details.url)) return;
  prunePending();
  // A redirected URL starts a new request context. Never carry headers across origins.
  const previous = pending.get(details.requestId);
  const redirectFrom = previous?.nextUrl === details.url ? previous.redirectFrom : undefined;
  pending.set(details.requestId, { url: details.url, redirectFrom, frameId: details.frameId, documentId: details.documentId,
    requestMethod: details.method, time: Date.now(), tabId: details.tabId });
}
function requestHeaders(details) {
  const event = pending.get(details.requestId);
  if (event && event.url === details.url) Object.assign(event, N.headers(details.requestHeaders), { observedHeaders: true });
}
function response(details) {
  if (details.tabId < 0 || ['main_frame', 'sub_frame', 'ping'].includes(details.type)) return;
  const contentType = N.mime(details.responseHeaders);
  const category = N.classify(details.url, details.type, contentType);
  if (!category) return;
  const old = pending.get(details.requestId);
  const context = old?.url === details.url ? old : {};
  const event = { ...context, url: N.url(details.url), frameId: details.frameId, documentId: details.documentId,
    requestMethod: details.method, time: Date.now(), category, mime: contentType, status: details.statusCode };
  delete event.tabId;
  save(details.tabId, event).catch(() => {});
}
chrome.webRequest.onBeforeRequest.addListener(request, FILTER);
chrome.webRequest.onBeforeRedirect.addListener(d => {
  const event = pending.get(d.requestId);
  if (event && N.url(d.redirectUrl)) {
    event.redirectFrom = event.redirectFrom || event.url;
    event.nextUrl = d.redirectUrl;
  }
}, FILTER);
try {
  chrome.webRequest.onBeforeSendHeaders.addListener(requestHeaders, FILTER, ['requestHeaders', 'extraHeaders']);
} catch {
  chrome.webRequest.onBeforeSendHeaders.addListener(requestHeaders, FILTER, ['requestHeaders']);
}
try {
  chrome.webRequest.onHeadersReceived.addListener(response, FILTER, ['responseHeaders', 'extraHeaders']);
} catch {
  chrome.webRequest.onHeadersReceived.addListener(response, FILTER, ['responseHeaders']);
}
chrome.webRequest.onCompleted.addListener(d => pending.delete(d.requestId), FILTER);
chrome.webRequest.onErrorOccurred.addListener(d => pending.delete(d.requestId), FILTER);
chrome.webNavigation.onCommitted.addListener(d => {
  serial(d.tabId, async () => {
    const rows = d.frameId === 0 ? [] : (await read(d.tabId)).filter(e => e.frameId !== d.frameId);
    await chrome.storage.session.set({ [key(d.tabId)]: rows });
    if (d.frameId === 0) chrome.action.setBadgeText({ tabId: d.tabId, text: '' }).catch(() => {});
  }).catch(() => {});
});
chrome.tabs.onRemoved.addListener(tab => {
  serial(tab, () => chrome.storage.session.remove(key(tab))).catch(() => {});
  for (const [id, event] of pending) if (event.tabId === tab) pending.delete(id);
});
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== chrome.runtime.id || !message || typeof message.type !== 'string') return;
  const tab = sender.tab?.id;
  if (message.type === 'ready' && tab !== undefined) {
    serial(tab, async () => {
      const events = (await read(tab)).filter(e => e.frameId === sender.frameId && (!e.documentId || e.documentId === sender.documentId));
      reply({ events });
    }).catch(() => reply({ events: [] }));
    return true;
  }
  if (message.type === 'clear' && tab !== undefined && sender.frameId === 0) {
    serial(tab, () => chrome.storage.session.remove(key(tab))).then(() => reply({ ok: true }), () => reply({ ok: false }));
    return true;
  }
  if (message.type === 'count' && tab !== undefined && sender.frameId === 0 && Number.isInteger(message.count)) {
    chrome.action.setBadgeText({ tabId: tab, text: message.count ? String(Math.min(150, Math.max(0, message.count))) : '' }).catch(() => {});
    chrome.action.setBadgeBackgroundColor({ tabId: tab, color: '#19563b' }).catch(() => {});
    reply({ ok: true });
  }
});

// Pairing and receiver addresses are controlled exclusively by the trusted popup.
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== chrome.runtime.id || !message?.type?.startsWith('tv-')) return;
  const popup = sender.url === chrome.runtime.getURL('popup.html');
  const page = !popup && sender.tab && sender.frameId === 0 && /^https?:\/\//.test(sender.url || '');
  let task;
  if (message.type === 'tv-state') task = FinderDevice.state().then(state => popup ? state : { paired: !!state.device });
  else if (popup && message.type === 'tv-pair-start') task = FinderDevice.pairStart(message.address);
  else if (popup && message.type === 'tv-pair-finish') task = FinderDevice.pairFinish();
  else if (popup && message.type === 'tv-forget') task = FinderDevice.forget();
  else if (page && message.type === 'tv-send') task = FinderDevice.send(message.carrier);
  else { reply({ error: 'This action requires the extension menu.' }); return; }
  task.then(reply, error => {
    const safe = new Set(['Pair the TV in the extension menu first.', 'Enter the private IPv4 address shown by Cloudstream on the TV.', 'Use a private Wi-Fi IPv4 address.', 'Open pairing on the TV, or pair again.', 'The TV rejected this request.', 'Pairing expired. Open pairing again on the TV.', 'Compare the six-digit code and approve this phone on the TV first.', 'Enable the TV companion receiver and check its Cloudstream player setting.', 'Update Browser Stream Bridge on the TV.']);
    reply({ error: safe.has(error.message) ? error.message : 'TV connection failed. Keep the receiver enabled, check the same Wi-Fi and pairing, and allow local-network access if the browser asks.' });
  });
  return true;
});
