'use strict';
document.querySelector('#open').addEventListener('click', async () => {
  const status = document.querySelector('#status');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https?:\/\//.test(tab.url || '')) throw new Error('restricted');
    await chrome.tabs.sendMessage(tab.id, { type: 'open' }, { frameId: 0 });
    window.close();
  } catch {
    status.textContent = 'Open a normal website, allow this extension on that site, and reload the page. Browser settings and store pages cannot be scanned.';
  }
});
async function tvRequest(type, data = {}) {
  const result = await chrome.runtime.sendMessage({ type, ...data });
  if (result?.error) throw Error(result.error);
  return result;
}
function showTv(state) {
  document.querySelector('#tv-state').textContent = state?.device ? `Paired: ${state.device.name} · ${state.device.address}` : 'No TV paired.';
  document.querySelector('#forget').hidden = !state?.device;
  document.querySelector('#finish').hidden = !state?.pending;
  document.querySelector('#pair-code').textContent = state?.pending ? `Code: ${state.pending.code}\nCompare this code and approve the phone on the TV, then finish pairing here.` : '';
  if (state?.pending) document.querySelector('#tv').open = true;
  if (state?.device) document.querySelector('#address').value = state.device.address;
}
async function action(button, task) {
  button.disabled = true;
  try { showTv(await task()); }
  catch (error) { document.querySelector('#pair-code').textContent = error.message; }
  finally { button.disabled = false; }
}
document.querySelector('#pair').onclick = event => action(event.currentTarget, () => tvRequest('tv-pair-start', { address: document.querySelector('#address').value }));
document.querySelector('#finish').onclick = event => action(event.currentTarget, () => tvRequest('tv-pair-finish'));
document.querySelector('#forget').onclick = event => action(event.currentTarget, () => tvRequest('tv-forget'));
tvRequest('tv-state').then(showTv).catch(() => {});
